# design.md — [JUDUL GAME] (Beta)

> Status: draft v0.2 · Target: demo single player (vertical slice) · Gaya visual: Swiss Editorial
> v0.2: memasukkan 7 aset nyata (2 karakter, 2 musuh, 1 background) — lihat §11.
> Semua angka (stat, rate gacha, harga, durasi) adalah **placeholder untuk di-tuning**.

---

## 0. Ringkasan

| Aspek | Keputusan |
|-------|-----------|
| Jenis game | Action-exploration + battle turn-based + gacha |
| Visual | 2D, art dari kamu (demo pakai placeholder) |
| Gacha | **Skill, senjata, skin** |
| Karakter | **Ditemukan lewat progres game** (bukan gacha) |
| Battle | **Party 4v4** |
| Mode | Demo single player, data siap untuk multiplayer |
| Stack | Next.js + Phaser + Zustand + Prisma |
| Aset beta | 7 file nyata: `char1` dan `char2` (masing-masing full-body + portrait), `slime`, `slimeking`, `cave`. Sisanya placeholder otomatis |

**Prinsip kerja**

1. **Satu mode aktif sekali waktu** (title / explore / dialogue / battle / menu). Input dikunci per mode.
2. **Konten = data, logika = fungsi murni.** Dialog, scene, karakter, skill ada di file data. Aturan battle dan gacha ada di modul TypeScript murni tanpa Phaser/React, jadi bisa dipindah ke server nanti.
3. **Tipografi dulu, dekorasi nanti.** Tanpa ikon rumit; pakai angka, garis, dan label.
4. **Beta = satu irisan vertikal yang lengkap**, bukan banyak fitur setengah jadi.

---

## 1. Scope Beta

**Masuk (in)**

- Title screen, 1 scene hub (background + karakter + item + pintu)
- Interaksi idle: hover → klik → popup opsi → dialog visual novel (+ pilihan)
- 4 karakter: `char1` (MC, party awal) + `char2`–`char4` yang ditemukan lewat progres. **Art tersedia untuk `char1` dan `char2`**; `char3` dan `char4` memakai placeholder
- Battle 4v4: Attack / Skill / Defend / Flee
- 1 mata uang (Token), gacha 3 banner (Skill, Weapon, Skin)
- Menu Party/Equip, autosave

**Tidak masuk (out) — sengaja ditunda**

Multiplayer, status effect (buff/debuff/poison), item pakai di battle, shop, crafting, peta dunia, sprite sheet animasi, voice, musik, cutscene, quest log, achievement, auto/skip/log dialog, lokalisasi.

---

## 2. Design Language — Swiss Editorial

### 2.1 Prinsip visual

- Grid ketat, komposisi asimetris, teks **rata kiri** (ragged-right), banyak ruang kosong.
- Hierarki dibuat dengan **ukuran dan berat huruf**, bukan warna atau dekorasi.
- Pemisah = **garis tipis (rule)**. Tanpa rounded corner, shadow, atau gradient.
- Urutan dan opsi ditandai **nomor** (01, 02, 03…).
- Satu warna aksen (merah). Warna "kaya" datang dari art game itu sendiri.
- Merah **tidak dipakai untuk teks kecil** (kontras tidak cukup). Hanya untuk blok, garis, dan bar.

### 2.2 Tokens

```css
:root {
  /* color */
  --paper:   #F2F0EB;   /* latar panel */
  --paper-2: #E6E3DC;   /* track bar, panel sekunder */
  --ink:     #111111;   /* teks, garis, fill HP */
  --ink-60:  rgba(17,17,17,.60);
  --ink-35:  rgba(17,17,17,.35);   /* disabled */
  --red:     #E8301C;   /* aksen: giliran aktif, HP kritis, level up marker */
  --cobalt:  #1F3FE0;   /* khusus bar MP */
  --white:   #FFFFFF;   /* highlight hover di scene */

  /* spacing (basis 8px) */
  --s1: 8px; --s2: 16px; --s3: 24px; --s4: 32px; --s6: 48px;

  /* type */
  --font-display: "Inter Tight", "Helvetica Neue", Arial, sans-serif;
  --font-body:    "Inter", "Helvetica Neue", Arial, sans-serif;
  --font-mono:    "IBM Plex Mono", ui-monospace, monospace;

  /* motion */
  --ease: cubic-bezier(.2, 0, 0, 1);
  --t-fast: 120ms; --t-base: 160ms; --t-slow: 240ms;
}
```

### 2.3 Tipografi

| Peran | Font | Ukuran / leading | Berat | Catatan |
|-------|------|------------------|-------|---------|
| Display (Victory, judul layar) | Inter Tight | 72 / 72 | 700 | tracking −2% |
| Heading (judul banner) | Inter Tight | 40 / 40 | 700 | |
| Dialog | Inter | 24 / 32 | 400 | maks 3 baris |
| Row / menu | Inter | 18 / 24 | 500 | |
| Label (nameplate, header) | Inter | 12 / 16 | 600 | UPPERCASE, tracking +8% |
| Angka (HP, MP, cost) | IBM Plex Mono | 14 / 16 | 500 | |
| Damage number | IBM Plex Mono | 28 / 28 | 700 | stroke paper 3px |

Kalau nanti butuh aksara Jepang: tambahkan Noto Sans JP sebagai fallback di `--font-body`.

### 2.4 Grid

Canvas logis **1280×720** (16:9, landscape saja). Margin 48, **12 kolom**, gutter 16, lebar kolom 84. Baseline 8px.

Posisi kiri kolom *n* = `48 + (n−1) × 100`. Contoh: kol 1 = 48, kol 4 = 348, kol 9 = 848, tepi kanan = 1232.

### 2.5 Komponen dasar

| Komponen | Spesifikasi |
|----------|-------------|
| **Panel** | bg `--paper` (96%), border-top 4px `--ink`, tanpa radius |
| **Rule** | 1px `--ink`, pemisah antar row |
| **Row** | tinggi 48 (battle: 40), isi: `nomor · label · info kanan`. Default: transparan. **Hover/fokus: bg `--ink`, teks `--paper`** (instan, tanpa transisi). Disabled: `--ink-35` + coret. Fokus keyboard: outline 2px `--red` |
| **Label** | 12px uppercase; dipakai di nameplate dan header popup |
| **Bar** | track `--paper-2`, tanpa radius. Field: tinggi 6. Panel: tinggi 12. HP fill `--ink`, **<25% jadi `--red`**. MP fill `--cobalt`. Angka mono di kanan: `072 / 100` |
| **Nameplate** | bg `--ink`, teks `--paper`, tinggi 32, padding 0 16 |

### 2.6 Motion

| Elemen | Durasi | Keterangan |
|--------|--------|------------|
| Hover hotspot (on/off) | 120ms | overlay putih 0 → 18% |
| Popup opsi buka | 160ms | clip-reveal dari atas |
| Dialog box masuk/keluar | 160ms | slide up 16px + fade |
| Ganti portrait | 160ms | crossfade (ganti ekspresi: 80ms) |
| Typewriter | 40 cps | setting: 20 / 40 / 80 |
| Transisi mode (explore ↔ battle) | 240ms + 240ms | panel `--ink` menyapu dari kiri sampai penuh, layar ganti, panel menyapu keluar |
| HP/MP bar tween | 240ms | |
| Damage number | 600ms | naik 24px lalu fade |
| Serang (lunge) | 160ms maju 40px, 120ms kembali | |

`prefers-reduced-motion`: semua durasi UI jadi 0 (kecuali typewriter).

---

## 3. Arsitektur Singkat

### 3.1 Pembagian tugas

| Lapisan | Tanggung jawab | Alasan |
|---------|----------------|--------|
| **Phaser** (canvas) | background, sprite karakter/item, hover highlight, hit-test, sprite battle + animasinya | cocok untuk visual 2D dan input pada sprite |
| **React DOM** (overlay) | dialog, popup opsi, menu, HUD battle, gacha, title | tipografi tajam (penting untuk Swiss), mudah dibuat aksesibel dan di-iterasi |
| **Zustand** | satu sumber kebenaran untuk state game | Phaser dan React sama-sama subscribe |
| **`/engine`** (TS murni) | aturan battle, gacha, evaluasi kondisi, efek | testable, bisa dipakai server |
| **Prisma** | hanya **state pemain** (save, inventori, pity, riwayat tarik) | konten game tetap file di repo |

Phaser harus client-only: `dynamic(() => import('@/game/Game'), { ssr: false })`.

### 3.2 Skala layar

Overlay React berukuran tetap 1280×720 lalu di-scale dengan CSS `transform: scale(var(--s))` agar selalu sama dengan canvas (`Phaser.Scale.FIT` + `CENTER_BOTH`). Jadi semua ukuran px di dokumen ini valid di semua layar. Mode portrait: tampilkan layar "Putar perangkat".

### 3.3 State machine mode

```
title ──New/Continue──▶ explore ◀──────────────┐
                          │  ▲                  │
              klik opsi   │  │ dialog selesai   │ victory / flee
                          ▼  │                  │
                       dialogue ──startBattle──▶ battle
                          
explore ──tombol MENU──▶ menu ──Esc──▶ explore
```

Aturan: hotspot hanya hidup saat `mode === 'explore'` dan tidak ada popup lain terbuka. Dialog tidak bisa ditutup, hanya selesai. Menu hanya dari explore.

### 3.4 Store (Zustand)

| Store | Isi |
|-------|-----|
| `useGame` | `mode`, `transition`, `setMode()` |
| `usePlayer` | `flags`, `party[]` (urutan slot), `chars{}`, `tokens`, `inventory`, `applyEffects()` |
| `useScene` | `sceneId`, hotspot yang terlihat, `popup {hotspotId, pos}` |
| `useDialogue` | `dialogueId`, `nodeId`, progres teks, `choices` |
| `useBattle` | state engine (immutable), antrean event animasi, `phase`: `command · skill · target · resolving · result` |

Phaser ↔ React: Phaser memancarkan event (`hotspot:click`, `battle:target`), React menulis ke store, Phaser `subscribe` store untuk update visual. Tidak ada pemanggilan langsung antar lapisan.

### 3.5 Struktur folder

```
/src
  /app            route: / (title), /play, /api/save, /api/gacha/pull
  /game           Phaser: Game.ts, scenes/ExploreScene.ts, scenes/BattleScene.ts,
                  objects/Hotspot.ts, placeholder.ts, bridge.ts
  /ui             React: Title, Dialogue, OptionPopup, BattleHud, Menu, Gacha, Result
  /stores         useGame, usePlayer, useScene, useDialogue, useBattle
  /engine         battle.ts, gacha.ts, conditions.ts, effects.ts, rng.ts  (murni, + test)
  /content        assets.ts (manifest aset + arah hadap), characters.ts, skills.ts,
                  weapons.ts, skins.ts, banners.ts, enemies.ts, encounters.ts,
                  strings.ts, scenes/*.json, dialogues/*.json
  /styles         tokens.css
/prisma/schema.prisma
/public/assets    characters/ enemies/ bg/ icon/
```

---

## 4. Mode Idle (Explore)

### 4.1 Susunan layar

```
┌──────────────────────────────────────────────────────────┐
│ ... BACKGROUND full-bleed ...                   [ MENU ] │
│                                                          │
│     [item]            ┌───────┐                          │
│                       │ CHAR  │ ─▶ ┌─────────────────┐   │
│                       │       │    │ NAMA HOTSPOT    │   │
│                       └───────┘    │ 01  Talk        │   │
│                                    │ 02  Examine     │   │
│                                    └─────────────────┘   │
└──────────────────────────────────────────────────────────┘
```

Tombol **MENU** di pojok kanan atas (kol 11–12, y 32), gaya Row kecil.

### 4.2 Hotspot dan hover

- **Hotspot** = karakter atau item yang bisa diinteraksi. Didefinisikan di data scene.
- **Hit area**
  - Sprite terpisah (disarankan): `pixelPerfect` berdasarkan alpha PNG, jadi area klik mengikuti siluet.
  - Item yang menyatu dengan background: pakai `hitArea` poligon di data.
- **Hover**: kursor jadi `pointer`; objek **memutih sedikit** (≈18% ke arah `--white`) dalam 120ms. Implementasi: kloning sprite dengan `tintFill` putih, tween alpha 0 → 0.18. Untuk poligon: isi poligon putih alpha 0.18. Cara ini bekerja baik dengan PNG transparan.
- Saat popup terbuka, hotspot yang dipilih tetap menyala 18% (penanda "terpilih"); hotspot lain tidak bisa di-hover.
- **Touch** tidak punya hover: tap hotspot langsung membuka popup. Tombol **◎** (di sebelah MENU) memunculkan sorotan semua hotspot selama 1,5 detik agar bisa ditemukan.

### 4.3 Popup opsi

- Muncul **menempel di kanan hotspot** (flip ke kiri jika melewati tepi kanan, geser ke atas jika melewati tepi bawah).
- Lebar 240. Header: label nama hotspot (12px uppercase) + rule. Lalu 1–4 Row bernomor.
- Opsi standar: **Talk, Examine, Take, Leave**. Setiap hotspot hanya menampilkan opsi yang relevan.
- Opsi yang `visibleIf`-nya tidak terpenuhi **disembunyikan** (bukan di-disable).
- Tutup: `Esc`, klik di luar, atau klik kanan.
- Memilih opsi → popup menutup → jalankan `do` (biasanya membuka dialog).

### 4.4 Kondisi dan efek (mini-DSL)

Dipakai di `visibleIf` dan di dialog. Sengaja kecil:

| Kondisi | Arti |
|---------|------|
| `flag:nama` / `!flag:nama` | flag true / false |
| `item:id` | punya item |
| `party>=2` | jumlah anggota party |

| Efek | Arti |
|------|------|
| `setFlag: {nama: nilai}` | set flag |
| `giveItem: id` | tambah item |
| `giveTokens: n` | tambah Token |
| `joinParty: charId` | karakter bergabung (ditemukan) |
| `startBattle: encounterId` | mulai battle |
| `unlock: "gacha"` | buka fitur |

### 4.5 Format data scene

```json
{
  "id": "cave_01",
  "background": "bg.cave",
  "hotspots": [
    {
      "id": "npc_char2",
      "name": "Char 2",
      "type": "character",
      "sprite": "char2.full",
      "pos": [420, 600],
      "hit": "alpha",
      "visibleIf": "!flag:char2_joined",
      "options": [
        { "label": "Talk",    "do": { "dialogue": "char2_intro" } },
        { "label": "Examine", "do": { "dialogue": "char2_look" } }
      ]
    },
    {
      "id": "door",
      "name": "Door",
      "type": "exit",
      "hit": { "polygon": [[1040,180],[1180,180],[1180,620],[1040,620]] },
      "options": [
        { "label": "Leave", "visibleIf": "party>=2", "do": { "dialogue": "door_confirm" } }
      ]
    }
  ]
}
```

`sprite` dan `background` adalah **key** dari manifest `content/assets.ts` (§11), bukan path file. `facing` (opsional, `"left"` / `"right"`) mengatur arah hadap di scene; jika berbeda dari arah asli aset, sprite di-flip. Default: arah asli.

---

## 5. Dialog (gaya Visual Novel)

### 5.1 Layout

```
┌──────────────────────────────────────────────────────────┐
│  BACKGROUND (gelap 25%)                  ┌──────────────┐│
│                                          │ 1  Pilihan A ││
│ ┌───────────┐                            │ 2  Pilihan B ││
│ │           │   ┌──────┐                 └──────────────┘│
│ │ PORTRAIT  │   │ NAMA │                                 │
│ │ (kiri     │   ├──────┴─────────────────────────────────┤
│ │  bawah)   │   │ Teks dialog 24/32, maks 3 baris…    ▪  │
│ └───────────┘   └────────────────────────────────────────┘
└──────────────────────────────────────────────────────────┘
```

| Elemen | Spesifikasi |
|--------|-------------|
| **Textbox** | Panel; x 348 → 1232 (kol 4–12), y 520 → 688 (tinggi 168), padding 32 |
| **Nameplate** | menempel di atas kiri textbox (y 488–520). Teks nama karakter, uppercase. Narator: nameplate disembunyikan, teks `--ink-60` |
| **Portrait** | memakai aset `*.portrait` (varian **b**). Rata bawah-kiri layar, x 48, tinggi tampil ±560. **Menghadap kanan** (ke arah textbox/tengah layar): aset yang aslinya menghadap kiri di-flip otomatis (§11.2). Diletakkan **di belakang** textbox (z-index lebih rendah) sehingga bagian bawah art tertutup rapi |
| **Dim** | overlay `rgba(17,17,17,.25)` di atas background selama dialog |
| **Indikator lanjut** | kotak merah 8×8 di kanan bawah textbox, berkedip 1 Hz setelah teks selesai |

### 5.2 Perilaku

1. Teks muncul dengan typewriter (default 40 cps).
2. Klik / `Space` / `Enter` **saat mengetik** → teks langsung lengkap. **Setelah lengkap** → node berikutnya.
3. Ganti pembicara → crossfade portrait. Pembicara sama, ganti ekspresi → crossfade cepat 80ms.
4. Semua pembicara memakai portrait kiri bawah (beta tidak punya layout multi-karakter).
5. Dialog selesai (`end: true`) → jalankan efek → kembali ke explore.

**Aturan penulisan:** maksimal 160 karakter per node; satu node = satu pembicara.

### 5.3 Pilihan

- Muncul **setelah teks selesai**, panel kanan di atas textbox (kol 7–12), rata bawah dengan jarak 16 dari textbox.
- 2–4 Row bernomor, label maks 48 karakter. Pilih dengan klik atau tombol `1`–`4`.
- Aturan beta: **pilihan tidak mengunci progres utama**. Pilihan hanya set flag dan/atau mengganti beberapa baris, sehingga tidak ada jalan buntu.

### 5.4 Format data dialog

```json
{
  "id": "char2_intro",
  "nodes": [
    { "id": "n1", "speaker": "char2", "expr": "neutral",
      "text": "Kamu orang baru, ya?", "next": "n2" },
    { "id": "n2", "speaker": "char2", "expr": "neutral",
      "text": "Aku bisa ikut kalau kamu butuh bantuan.",
      "choices": [
        { "label": "Ikut aku.",      "next": "n3", "set": { "b_trust": 1 } },
        { "label": "Boleh juga.",    "next": "n3" }
      ] },
    { "id": "n3", "speaker": "narrator", "text": "Char 2 bergabung.",
      "effects": [ { "joinParty": "char2" }, { "setFlag": { "char2_joined": true } } ],
      "end": true }
  ]
}
```

---

## 6. Battle (Turn-based)

### 6.1 Layout

```
┌──────────────────────────────────────────────────────────────┐
│ BATTLE 01 — Nama Encounter   [P1][E1][P2][E2][P3]…    R 03   │  y 0–48
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  [P4]  [P3]  [P2]  [P1]                [E1]  [E2]  [E3] [E4] │  field
│  ▔▔▔▔  ▔▔▔▔  ▔▔▔▔  ▔▔▔▔                ▔▔▔▔  ▔▔▔▔  ▔▔▔▔ ▔▔▔▔ │  y 48–504
│                                                              │
├──────────────────────────────────────────────────────────────┤
│ 01 Attack     │ LOG / DESKRIPSI           │ NAMA      ┌────┐ │
│ 02 Skill      │                           │ HP ████░░ │    │ │  y 520–688
│ 03 Defend     │                           │ MP ███░░░ │ POR│ │
│ 04 Flee       │                           │           └────┘ │
└──────────────────────────────────────────────────────────────┘
```

| Area | Spesifikasi |
|------|-------------|
| **Top bar** (tinggi 48) | kiri: label encounter · tengah: **turn order** (maks 8 kotak 32×32) · kanan: `R 03` |
| **Turn order** | kotak berisi 2 huruf inisial (mono). Party: border `--ink`, bg `--paper`. Musuh: bg `--ink`, teks `--paper`. **Yang aktif: garis bawah 3px `--red`** |
| **Party** (kiri) | berbaris horizontal di **lane kiri (x 48 → 564)**. **Slot 1 paling kanan (paling dekat musuh)**, slot 4 paling kiri. Sprite = aset `*.full` (varian **a**), baseline y 440, **menghadap kanan** (flip otomatis jika aset aslinya menghadap kiri). Penempatan: §6.1a |
| **Musuh** (kanan) | **lane kanan (x 716 → 1232)**, E1 paling kiri (paling dekat party). Baseline y 440, **menghadap kiri** (flip otomatis jika aset aslinya menghadap kanan). Penempatan: §6.1a |
| **Bar di field** | HP 6px di bawah setiap sprite (party & musuh), selebar sprite (min 64, maks 120). Tanpa angka |
| **Command menu** | kol 1–3 (x 48–332). 4 Row tinggi 40 |
| **Log / deskripsi** | kol 4–8. 3 baris terakhir (terbaru di bawah, yang lama `--ink-60`). Saat fokus ke skill: tampil deskripsi, power, tipe target |
| **Panel karakter aktif** | kanan bawah (x 848–1232). Kiri: nama (label), bar **HP** dan **MP** (lebar 200, dengan angka mono), chip status (`GUARD`). Kanan: **portrait persegi 168×168** (crop dari aset `*.portrait`, varian **b**) di x 1064–1232, y 520–688, **menghadap kiri** (ke tengah layar; flip otomatis) |
| **Background battle** | `bg.cave`, gelap 20% (beta: satu background untuk semua encounter) |

**Crop portrait:** default = persegi dari **atas-tengah** gambar portrait (sisi = lebar gambar). Jika wajah kurang pas, atur `portraitCrop: {x, y, w, h}` per karakter di data. Tidak butuh aset tambahan.

**6.1a Penempatan sprite (lane + auto-fit)**

Ukuran file tidak mempengaruhi layout. Yang dipakai adalah **tinggi tampil** (`battleHeight`, di data), lebar mengikuti rasio gambar.

1. Tiap sprite diskalakan ke `battleHeight` (placeholder: karakter 300, `slime` 140, `slimeking` 300).
2. Disusun dari ujung dalam lane (party: dari x 564 ke kiri; musuh: dari x 716 ke kanan) dengan jarak 8px antar sprite.
3. Jika total lebar melebihi lane (516px), semua sprite di sisi itu diskalakan turun seragam (minimum 70%). Jika masih tidak muat, sprite boleh saling tumpang maksimal 25%, slot yang lebih dekat ke tengah berada di depan.
4. Kaki semua sprite sejajar di baseline y 440; titik tumpu = tengah-bawah gambar.

Aturan ini menjaga formasi 4v4 tetap rapi walau ada musuh besar seperti `slimeking`.

### 6.2 Alur giliran

1. **Urutan** = SPD tertinggi dulu (seri → party dulu). Dihitung ulang tiap ronde. Bukan ATB.
2. Giliran party → pemain memilih command. Giliran musuh → AI memilih otomatis.
3. Aksi dieksekusi oleh engine → menghasilkan daftar **event** (`attack`, `damage`, `heal`, `guard`, `defeat`, `flee`…) → UI memutar event berurutan (animasi) → lanjut ke giliran berikutnya.
4. Setelah tiap aksi: cek semua musuh KO → **Victory**; semua party KO → **Defeat**.

### 6.3 Command

| # | Command | Perilaku |
|---|---------|----------|
| 01 | **Attack** | serangan dasar ke 1 musuh. Tanpa biaya. Lanjut ke pilih target |
| 02 | **Skill** | daftar command **diganti** submenu skill (geser masuk 160ms). Header `← SKILL` (juga `Esc` / klik kanan untuk kembali). Maks 4 Row, tinggi 36: `nama … 12 MP`. MP kurang → disabled. Fokus Row → deskripsi muncul di log. Pilih skill → pilih target (kecuali tipe `all` / `self`) |
| 03 | **Defend** | langsung dieksekusi. Damage yang diterima **×0.5 sampai giliran berikutnya**, dan **+5 MP**. Chip `GUARD` muncul |
| 04 | **Flee** | peluang berhasil = `clamp(0.5 + (SPD party − SPD musuh) × 0.01, 0.2, 0.9)`. Berhasil → keluar battle tanpa hadiah. Gagal → giliran hangus, log "Failed to flee". **Tidak bisa dipakai di battle boss** (Row disabled) |

Navigasi: klik, `↑↓` + `Enter`, atau tombol `1`–`4`.

### 6.4 Pemilihan target

- Setelah command butuh target, log menampilkan `Select target — Esc to cancel`.
- Target valid **menyala putih 18%**, sama dengan hover di mode idle (bahasa interaksi yang konsisten). Hover target = menyala lebih terang (30%).
- Klik target = konfirmasi. `Tab` / `←→` memindah target, `Enter` konfirmasi.
- Skill `all enemies` / `all allies`: semua target valid menyala sekaligus, klik salah satunya untuk konfirmasi.
- Skill heal memilih target dari party.

### 6.5 Rumus (placeholder)

```
damage = max(1, round((ATK × power − DEF × 0.5) × rand(0.9, 1.1)))
heal   = round(ATK × power × rand(0.9, 1.1))
if target.guard: damage = round(damage × 0.5)
stat(level) = base × (1 + 0.12 × (level − 1))        // level maks 10 di beta
exp to next = 50 × level
```

`rand` memakai RNG ber-seed (`mulberry32`) agar battle **deterministik** dan bisa diverifikasi server nanti.

### 6.6 AI musuh (beta)

Pilih aksi: 70% Attack, 30% skill jika punya dan MP cukup. Target: acak di antara party yang hidup. Tanpa strategi lain.

### 6.7 Animasi aksi

1. Penyerang maju 40px (160ms) → kembali (120ms).
2. Target berkedip putih 80ms + goyang 4px.
3. Damage number naik 24px dan fade (600ms). Damage = `--ink` dengan stroke `--paper`; heal = diawali `+`.
4. HP bar tween 240ms; jika <25% jadi merah.
5. KO: sprite fade ke 0 (musuh) atau jadi grayscale 60% (party), 240ms.

### 6.8 Hasil

**Victory** (overlay, layout dua kolom):

- Kiri (kol 1–6): `Victory` display 72px.
- Kanan (kol 7–12): daftar `EXP +N` per karakter, `Tokens +N`, item drop. Level up ditandai kotak merah 8×8 + `LV 3 → 4`.
- Tombol `Continue ↵`.
- Setelah itu **HP/MP semua party dipulihkan penuh** (tanpa atrisi di beta).

**Defeat**: heading `Defeat`, dua Row: `01 Retry` (ulang battle, HP penuh) dan `02 Return` (kembali ke explore). Tidak ada hukuman.

---

## 7. Karakter dan Progres

**Aturan**

- Party **1–4** anggota; urutan = slot 1…4 (slot 1 paling depan). Dapat diatur di menu Party.
- Karakter **ditemukan lewat progres** (efek `joinParty`), bukan gacha.
- Setiap karakter: level (maks 10), EXP, 1 senjata, 4 slot skill, 1 skin.

**Roster beta (peran dan stat placeholder — sesuaikan dengan karakter aslinya)**

| id | Peran | HP | MP | ATK | DEF | SPD | Skill bawaan (slot 1, terkunci) | Art |
|----|-------|----|----|-----|-----|-----|---------------------------------|-----|
| `char1` (MC) | Seimbang | 100 | 30 | 12 | 6 | 10 | Slash — power 1.5, 5 MP, 1 musuh | ✓ |
| `char2` | Tank | 140 | 20 | 9 | 10 | 6 | Shield Bash — power 1.2, 4 MP, 1 musuh | ✓ |
| `char3` | Caster | 80 | 60 | 14 | 4 | 9 | Fire Burst — power 1.0, 10 MP, semua musuh | placeholder |
| `char4` | Healer | 90 | 50 | 8 | 5 | 12 | Mend — heal power 2.0, 8 MP, 1 ally | placeholder |

**Musuh beta**

| id | Art | HP | ATK | DEF | SPD | EXP |
|----|-----|----|-----|-----|-----|-----|
| `slime` | `slime` | 60 | 8 | 3 | 7 | 20 |
| `slimeking` (boss) | `slimeking` | 260 | 14 | 8 | 9 | 120 |

`brute` dari draft sebelumnya dihapus (tidak ada art dan tidak dipakai di alur beta).

---

## 8. Gacha dan Equip

### 8.1 Aturan

| Item | Nilai (placeholder) |
|------|---------------------|
| Mata uang | **Token** (hanya dari gameplay; tidak ada pembelian uang asli) |
| Harga | 100 / tarikan. ×10 = 1000 (tanpa diskon) |
| Banner | 3 tab: **01 Skill · 02 Weapon · 03 Skin**, masing-masing punya pool dan pity sendiri |
| Rarity & rate | R 70% · SR 25% · SSR 5% |
| Pity | SSR dijamin di tarikan ke-60 (hitung sejak SSR terakhir). Paket ×10 menjamin minimal 1 SR |
| Pool per banner | 8 item placeholder: 4 R, 3 SR, 1 SSR |
| Duplikat | Skill/Weapon → **rank +1** (maks 3; tiap rank +10% efek). Lewat batas, dan semua duplikat Skin → refund 30 Token |

**Efek per rarity**

| | R | SR | SSR |
|--|---|----|-----|
| Weapon (ATK flat) | +2 | +4 | +7 |
| Skill (power) | 1.2–1.4 | 1.6–1.8 | 2.2 |
| Skin | kosmetik saja: ganti portrait & sprite | | |

### 8.2 Layar Gacha

```
┌──────────────────────────────────────────────────────────┐
│ 01 Skill  │  JUDUL BANNER                │ TOKENS   0900 │
│ 02 Weapon │  (Display 72, maks 2 baris)  │ PITY     07/60│
│ 03 Skin   │  Deskripsi singkat           │               │
│           │  [ item unggulan ]           │ [ Pull ×1 ]   │
│           │                              │ [ Pull ×10]   │
└──────────────────────────────────────────────────────────┘
```

- Rail kiri kol 1–2 (tab bernomor), konten kol 3–9, panel kanan kol 10–12.
- Tombol disabled jika Token kurang.
- **Hasil tarikan**: overlay penuh, grid 5×2. Kartu muncul berurutan (stagger 120ms). Rarity ditandai **label teks** `R / SR / SSR`; SSR memakai garis atas merah 4px. Tombol `Skip` menampilkan semua sekaligus, lalu `Close`.
- Tanpa efek ledakan/partikel; reveal tetap tenang dan tipografis.

### 8.3 Alur tarik (server-side walau demo)

```
POST /api/gacha/pull { bannerId, count, idempotencyKey }
 → validasi Token  → engine.pullGacha(banner, pity, count, rng(seed))
 → transaksi Prisma: kurangi Token, update Pity, upsert OwnedItem, simpan Pull(seed, results)
 → return { results, tokens, pity }
```

Dihitung di server dari hari pertama supaya tidak perlu dirombak saat multiplayer.

### 8.4 Equip (di menu Party)

- Per karakter: **1 Weapon, 4 Skill (slot 1 terkunci bawaan), 1 Skin**.
- Klik slot → popup daftar item yang dimiliki (Row bernomor). Item yang sedang dipakai karakter lain ditandai `IN USE`; memilihnya memindahkan item.

---

## 9. Layar Lain

**Title**

- Judul game besar rata kiri (Display), 3 Row: `01 New Game`, `02 Continue` (disabled jika belum ada save), `03 Settings`.
- Sisi kanan: crop `bg.cave` (beta; key visual khusus menyusul).

**Menu** (overlay penuh, bg `--paper`, buka dengan `MENU` atau `M`, tutup dengan `Esc`)

- Tab bernomor: `01 Party` · `02 Gacha` (disabled sampai flag `gacha_unlocked`) · `03 Settings`.
- **Party**: kiri daftar karakter (Row 01–04) + tombol urut slot; tengah portrait besar + tabel stat (HP, MP, ATK, DEF, SPD, Level, EXP); kanan slot equip.
- **Settings** (hanya 2 di beta): kecepatan teks (Slow / Normal / Fast), `Reset save` (dengan konfirmasi dua langkah).

**Akhir demo**: setelah Battle 2 menang, kartu `End of Demo` dengan Row `Return to Title` dan `Keep Exploring`.

---

## 10. Data dan Persistensi

### 10.1 Pembagian

| Disimpan di | Isi |
|-------------|-----|
| **File repo (`/content`)** | karakter, skill, weapon, skin, banner, musuh, encounter, scene, dialog, string UI |
| **Database (Prisma)** | save, karakter yang dimiliki, inventori gacha, pity, riwayat tarik |

Demo: SQLite + pemain **guest** (cookie `pid`) — tetap ada `playerId` dari awal. Nanti: ganti provider ke Postgres + tambah auth.

### 10.2 Skema Prisma

```prisma
datasource db { provider = "sqlite" url = env("DATABASE_URL") }  // nanti: postgresql
generator client { provider = "prisma-client-js" }

model Player {
  id        String           @id @default(cuid())
  createdAt DateTime         @default(now())
  save      Save?
  chars     OwnedCharacter[]
  items     OwnedItem[]
  pities    Pity[]
  pulls     Pull[]
}

model Save {
  playerId  String   @id
  player    Player   @relation(fields: [playerId], references: [id])
  sceneId   String
  flags     Json     @default("{}")
  party     Json     @default("[]")     // ["char1","char2",...] urutan slot 1..4
  tokens    Int      @default(0)
  updatedAt DateTime @updatedAt
}

model OwnedCharacter {
  playerId String
  charId   String
  level    Int      @default(1)
  exp      Int      @default(0)
  equip    Json     @default("{}")      // { weaponId, skillIds[], skinId }
  player   Player   @relation(fields: [playerId], references: [id])
  @@id([playerId, charId])
}

model OwnedItem {
  id       String @id @default(cuid())
  playerId String
  kind     String                        // "skill" | "weapon" | "skin"
  defId    String
  rank     Int    @default(1)
  player   Player @relation(fields: [playerId], references: [id])
  @@unique([playerId, kind, defId])
}

model Pity {
  playerId String
  bannerId String
  count    Int    @default(0)
  player   Player @relation(fields: [playerId], references: [id])
  @@id([playerId, bannerId])
}

model Pull {
  id        String   @id @default(cuid())
  playerId  String
  bannerId  String
  count     Int
  results   Json
  seed      String
  createdAt DateTime @default(now())
  player    Player   @relation(fields: [playerId], references: [id])
}
```

### 10.3 Autosave

Disimpan otomatis setelah: dialog selesai, battle selesai, perubahan equip/party, dan tiap tarikan gacha (server). Flag dan party dikirim ke `/api/save` dengan debounce 500ms. Pada demo klien dipercaya untuk flag; untuk multiplayer, server memvalidasi.

### 10.4 Engine murni (wajib punya unit test)

```ts
createBattle(party, enemies, seed): BattleState
getTurnOrder(state): UnitId[]
resolveAction(state, action): { state: BattleState; events: BattleEvent[] }
pullGacha(banner, pityCount, count, rng): PullResult[]
evalCondition(expr, ctx): boolean
applyEffects(effects, playerState): PlayerState
```

UI **tidak menghitung apa pun**; ia hanya menampilkan `events`. Tes dengan Vitest: seed yang sama → hasil battle dan gacha yang sama.

---

## 11. Aset

Prinsip: game harus bisa dijalankan **tanpa aset asli**. Aset yang belum ada (`char3`, `char4`, item, ikon gacha, skin) digambar otomatis oleh `placeholder.ts` (kotak abu-abu + inisial + silang). Menggantinya = taruh file lalu daftarkan key-nya di manifest.

### 11.1 Aset yang sudah ada (7 file)

Konvensi nama: `{nama}-{a|b}-{l|r}.{ext}` → **a** = full-body, **b** = portrait, **l / r** = arah hadap **asli** gambar (kiri / kanan). Musuh: `{nama}-{l|r}.{ext}`.

| Key | File | Arah asli | Dipakai untuk |
|-----|------|-----------|---------------|
| `char1.full` | `char1-a-l.webp` | kiri | scene (jika karakter ada di scene), sprite battle party |
| `char1.portrait` | `char1-b-l.png` | kiri | portrait dialog, portrait panel battle (kanan bawah) |
| `char2.full` | `char2-a-r.png` | kanan | scene (hotspot Talk), sprite battle party |
| `char2.portrait` | `char2-b-r.webp` | kanan | portrait dialog, portrait panel battle |
| `slime` | `slime-r.png` | kanan | musuh biasa (sprite battle) |
| `slimeking` | `slimeking-l.webp` | kiri | musuh boss (sprite battle) |
| `bg.cave` | `cave.jpg` | — | background scene, battle, title |

Lokasi: `/public/assets/characters/`, `/enemies/`, `/bg/`. Format campuran (webp, png, jpg) tidak masalah karena manifest menyimpan nama file lengkap.

### 11.2 Arah hadap dan flip otomatis

Setiap aset mendeklarasikan arah aslinya di manifest. Setiap tempat pemakaian menentukan arah yang **diinginkan**. Jika berbeda → `flipX`. Tidak ada flip manual.

```ts
// content/assets.ts
export const assets = {
  'char1.full':     { file: 'characters/char1-a-l.webp', facing: 'left'  },
  'char1.portrait': { file: 'characters/char1-b-l.png',  facing: 'left'  },
  'char2.full':     { file: 'characters/char2-a-r.png',  facing: 'right' },
  'char2.portrait': { file: 'characters/char2-b-r.webp', facing: 'right' },
  'slime':          { file: 'enemies/slime-r.png',       facing: 'right' },
  'slimeking':      { file: 'enemies/slimeking-l.webp',  facing: 'left'  },
  'bg.cave':        { file: 'bg/cave.jpg' },
} as const

const needsFlip = (asset, wanted) => asset.facing !== wanted
```

| Pemakaian | Arah diinginkan | Hasil |
|-----------|-----------------|-------|
| Portrait dialog (kiri bawah) | menghadap kanan | `char1` flip · `char2` tetap |
| Sprite party di battle | menghadap kanan | `char1` flip · `char2` tetap |
| Portrait panel battle (kanan bawah) | menghadap kiri | `char1` tetap · `char2` flip |
| Sprite musuh di battle | menghadap kiri | `slime` flip · `slimeking` tetap |
| Sprite di scene | `facing` di data scene (default: arah asli) | tanpa flip kecuali diminta |

Konsekuensi: bagian art yang asimetris (teks, lambang, aksesori satu sisi) ikut tercermin saat di-flip.

### 11.3 Ukuran tampil

Ukuran piksel file bebas; yang dipakai adalah tinggi tampil (placeholder, di-tuning setelah dicoba dengan art asli). Saran: tinggi file minimal 2× tinggi tampil agar tajam di layar retina.

| Pemakaian | Tinggi tampil |
|-----------|---------------|
| Sprite di scene | ±500 |
| Portrait dialog | ±560 (rata bawah-kiri, terpotong tepi layar bila lebih tinggi) |
| Sprite party di battle (`battleHeight`) | 300 |
| `slime` di battle | 140 |
| `slimeking` di battle | 300 |
| Portrait panel battle | crop persegi 168×168 |

### 11.4 Yang masih placeholder

`char3` dan `char4` (`full` + `portrait`), item `key_hub`, ikon item gacha (24), skin (tint / hue-rotate dari art dasar), key visual title. Beta hanya punya **satu portrait per karakter (netral)**: field `expr` di dialog diabaikan sampai ada varian.

Animasi beta **hanya tween** (bob idle, lunge, shake, fade) — tidak butuh sprite sheet.

---

## 12. Alur Beta (end-to-end)

| # | Mode | Apa yang terjadi |
|---|------|------------------|
| 1 | title | New Game → transisi → hub gua `cave_01` (party: hanya `char1`) |
| 2 | explore | Hotspot: `npc_char2` (karakter), `item_key` (item), `npc_char3` (tersembunyi dulu), `door` (exit, Leave butuh `party>=2`) |
| 3 | dialogue | **Talk `npc_char2`** → 1 pilihan (tidak mengunci) → `char2` bergabung |
| 4 | dialogue | **Examine `item_key`** → dapat `key_hub` + flag `key_found` → `npc_char3` muncul |
| 5 | dialogue | **Talk `npc_char3`** → `char3` bergabung (party 3) |
| 6 | dialogue → battle | **Leave `door`** → konfirmasi (Yes/No) → Battle 1: 3 `slime` |
| 7 | battle | Menang → **+1000 Token** → flag `gacha_unlocked` + `battle1_done` |
| 8 | explore | `npc_char4` muncul → Talk → `char4` bergabung (party 4) |
| 9 | menu | Coba gacha (10 tarikan), atur equip dan urutan party |
| 10 | battle | **Leave `door`** lagi → Battle 2 (4v4): 3 `slime` + 1 `slimeking` (boss, Flee disabled) |
| 11 | result | Menang → kartu **End of Demo** |

Tujuan alur: menguji semua sistem sekali (flag, dialog bercabang, penemuan karakter, battle penuh, gacha, equip) dengan konten minimum.

**Catatan art:** `char3` dan `char4` tetap bisa dimainkan penuh (4v4) memakai placeholder. **Versi 2 karakter** (hanya art yang ada sekarang): lewati langkah 5 dan 8; Battle 1 jadi 2v3 dan Battle 2 jadi 2v2 (`slimeking` + 1 `slime`). Semua sistem tetap teruji, hanya formasi 4v4 yang belum.

---

## 13. Input dan Aksesibilitas

| Aksi | Mouse | Keyboard | Touch |
|------|-------|----------|-------|
| Hover hotspot | pointer di atas objek | `Tab` memindah fokus (tampil seperti hover) | tombol ◎ |
| Buka popup | klik | `Enter` pada fokus | tap objek |
| Lanjut dialog | klik di mana saja | `Space` / `Enter` | tap |
| Pilih opsi/pilihan | klik Row | `1`–`4` atau `↑↓` + `Enter` | tap |
| Batal / kembali | klik kanan / klik luar | `Esc` | tap luar / Row kembali |
| Menu | tombol MENU | `M` | tombol MENU |

- Kontras: `--ink` di atas `--paper` ≈ 15:1. Teks minimum 12px (pada basis 1280).
- Informasi tidak hanya lewat warna: rarity pakai label teks; HP kritis ditambah angka; giliran aktif ditambah garis bawah.

---

## 14. Asumsi yang Perlu Kamu Cek

Ini keputusan yang aku ambil sendiri supaya dokumen utuh. Kalau tidak cocok, bilang saja.

1. **Portrait kanan bawah di battle = karakter yang sedang giliran** (bukan semua anggota). Semua anggota tetap terlihat lewat sprite + HP bar kecil di field.
2. **"Urutan kanan ke kiri"** kuartikan: slot 1 paling kanan (paling dekat musuh), slot 4 paling kiri.
3. **Skill**: tiap karakter punya 1 skill bawaan (terkunci) + 3 slot untuk skill dari gacha.
4. Semua **angka** (stat, rate, harga, level cap, formula) hanya placeholder.
5. **Label UI berbahasa Inggris** (Attack, Skill, Defend, Flee, Talk, Examine…), semua ada di `content/strings.ts` jadi mudah diganti. Isi dialog bebas bahasa apa pun.
6. Resolusi **1280×720 landscape saja**.
7. Konten (dialog, scene, karakter) berupa **file di repo**; database hanya untuk state pemain.
8. **Pilihan dialog tidak mengunci progres** utama di beta.
9. **HP/MP pulih penuh** setelah setiap battle; tidak ada atrisi.
10. Warna **merah `#E8301C`** dan **cobalt `#1F3FE0`** adalah default; ganti di `tokens.css`.
11. **`char1` = MC** (party awal) dan **`char2` = karakter pertama yang ditemukan**. Kalau terbalik, cukup tukar di `content/characters.ts`.
12. **`slime` = musuh biasa, `slimeking` = boss** (Flee dimatikan saat melawan boss).
13. **Flip otomatis** sesuai arah hadap (§11.2). Kalau ada art yang tidak boleh di-flip (teks atau lambang asimetris), bilang, nanti dikecualikan.
14. File `char2-b-r-webp` kuanggap **`char2-b-r.webp`** (kemungkinan typo titik).
15. **Ukuran piksel asli file belum kuketahui.** Semua tinggi tampil (§11.3) dan lane battle (§6.1a) adalah placeholder sampai dicoba dengan art aslinya.
16. Portrait hanya **satu ekspresi (netral)** per karakter di beta.

---

## 15. Definition of Done — Beta

- [ ] Alur §12 bisa dimainkan dari title sampai End of Demo tanpa error
- [ ] Hover → klik → popup → dialog bekerja dengan mouse, keyboard, dan touch
- [ ] Battle 4v4: Attack, Skill (+target), Defend, Flee semuanya berfungsi; Victory dan Defeat tampil
- [ ] Gacha 3 banner: tarik ×1 dan ×10, pity tercatat, duplikat ditangani, hasil tersimpan di DB
- [ ] Equip: weapon, skill, skin, dan urutan party mengubah battle dan tampilan
- [ ] Refresh halaman → Continue memulihkan state yang sama
- [ ] Seluruh game jalan dengan **aset placeholder saja** (art yang belum ada tidak menyebabkan error)
- [ ] 7 aset nyata tampil dengan arah hadap benar (flip otomatis sesuai §11.2) dan formasi 4v4 muat di lane tanpa tumpang tindih berlebihan
- [ ] Unit test engine lulus (battle deterministik, gacha deterministik, kondisi/efek)
- [ ] Semua UI mengikuti tokens (tanpa radius, shadow, gradient)
